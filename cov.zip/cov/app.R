setwd("D://Desktop//11月底结题//cov")
#install.packages("waiter")
library(shiny)
# 从 CRAN 加载的包
library(shinyjs)
library(highcharter)
library(dplyr)
library(purrr)
#library(geojsonio)
library(stringr)
library(argonR)
#install.packages("argonR")
#install.packages("argonDash")
library(argonDash)
library(data.table)
#install.packages("DT")
library(DT)
#install.packages("shinycssloaders")
library(shinycssloaders)
#install.packages("shinyWidgets")
library(shinyWidgets)
library(waiter)
#install.packages("NLP")
library(NLP)
#install.packages("twitteR")
library(twitteR)
#install.packages("syuzhet")
library(syuzhet)
#install.packages("tm")
library(tm)
#install.packages("SnowballC")
library(SnowballC)
#install.packages("stringi")
library(stringi)
#install.packages("topicmodels")
library(topicmodels)
#install.packages("ROAuth")
library(ROAuth)
#install.packages("wordcloud")
library(wordcloud)
#install.packages("shinyBS")
library(shinyBS)
library(deSolve)
library(broom)
library(countup)
library(openxlsx)
##### Global: options #####
#file("filename", "r", encoding = "UTF-8")
#file("C://Users//WD//Desktop//cov//your_file_name.txt", "r", encoding = "UTF-8")
data4 <- read.xlsx("zl2.xlsx")
str(data4)
data4[] <- lapply(data4, as.factor)
fit3<- glm(是否感染~新冠疫苗接种情况+是否患有慢性病+是否伤残人士+是否为孕妇+哪类人员+性别+年龄段+居住地,family=binomial(link = "logit"),data = data4)




Production = T 
options(scipen = 1000, expressions = 10000)
appVersion = "v2.0"
appName = "COVID-19 数据分析可视化平台"
appLongName = "COVID-19 数据分析可视化平台"
lastUpdate = Sys.Date()

loader <- tagList(
  waiter::spin_loaders(42),
  br(),
  h3("Loading data")
)

jsToggleFS <- 'shinyjs.toggleFullScreen = function() {
var element = document.documentElement,
enterFS = element.requestFullscreen || element.msRequestFullscreen || element.mozRequestFullScreen || element.webkitRequestFullscreen,
exitFS = document.exitFullscreen || document.msExitFullscreen || document.mozCancelFullScreen || document.webkitExitFullscreen;
if (!document.fullscreenElement && !document.msFullscreenElement && !document.mozFullScreenElement && !document.webkitFullscreenElement) {
enterFS.call(element);
} else {
exitFS.call(document);
}
}'



#source("appFiles/packageLoad.R")
source("appFiles/dataLoad.R")
source("appFiles/CSS.R", local = TRUE)
source("appFiles/dashboardPage.R", local = TRUE)
##### User interface #####
ui <- tagList( # dependencies
  use_waiter(),
  useSweetAlert(),
  useShinyjs(),
  extendShinyjs(text = jsToggleFS,functions =  c("foo", "bar")),
  waiter::waiter_show_on_load(loader, color = "#000"),
  # shows before anything else
  ##### CSS and style functions #####
  CSS, #CSS.R
  # Loading message
  argonDash::argonDashPage(
    title = appLongName,
    header = argonDash::argonDashHeader(
      gradient = T,
      color = NULL,
      top_padding = 2,
      bottom_padding = 0,
      background_img = "coronavirus.jpg",
      height = 70,

      
      
    ),
    sidebar = NULL,
    body = argonDashBody(
      tags$head( tags$meta(name = "viewport", content = "width=1600"),uiOutput("body")),
      tags$br(),
      dashboardUI
    )
  )
)

##### server #####
server <- function(input, output, session) {
  printLogJs = function(x, ...) {
    logjs(x)
    T
  }
  # addHandler(printLogJs)
  if (!Production) options(shiny.error = recover)
  options(shiny.sanitize.errors = TRUE, width = 160)
  
  session$onSessionEnded(function() {
    stopApp()
    # q("no")
  })
  source("appFiles/dashboardServer.R", local = TRUE)
  # Hide the loading message when the rest of the server function has executed
  waiter_hide() # will hide *on_load waiter
}

# Run the application
shinyApp(ui = ui, server = server)