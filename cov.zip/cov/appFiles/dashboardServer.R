results = reactiveValues(
  dataframeTotal = NULL,
  dfDaily = NULL,
  newCases = NULL,
  dataframeTotalOldCases = NULL,
  newCasesDeath = NULL,
  dataframeFinal = NULL,
  newCasesRecovered = NULL,
  dataframeOldCases = NULL,
  modelFit = NULL,
  resultTable = NULL
)
output$dashboard = renderUI({
  argonTabSet(
    id = "analysisSettingsTabs",
    card_wrapper = T,
    horizontal = TRUE,
    circle = F,
    size = "sm",
    width = 12,
    iconList = list(
      icon("home"),
      icon("tachometer-alt"), 
      icon("laptop-code"), 
      icon("chart-line"),
      icon("user")
    ),
    argonTab(
      tabName = "首页",
      active = T,
      argonRow(
        argonColumn(
          width = 4,
          img(src = 'covid.jpg',width = "100%"),
          h6("图片来源: Wikipedia",style = 'text-align:center;
             font-style: italic;font-weight: bold;
             ')
          ),
        argonColumn(
          width = 5,
          p(" 新型冠状病毒简介：

新型冠状病毒（SARS-CoV-2）是一种冠状病毒，于2019年底首次在中国湖北省武汉市被发现，并引发了全球范围内的疫情。这种病毒属于冠状病毒科，是一种包膜的单链RNA病毒，因其表面的刺突状结构在显微镜下呈现类似“皇冠”而得名。

 病毒特性：
新型冠状病毒是β冠状病毒家族中的一员，与之前的SARS-CoV（严重急性呼吸综合征冠状病毒）和MERS-CoV（中东呼吸综合征冠状病毒）有一定的遗传相似性。它的基因组约为30,000个核苷酸，编码多种非结构蛋白、结构蛋白和辅助蛋白，其中刺突蛋白（Spike Protein）是病毒与宿主细胞结合的关键。

 传播途径：
新型冠状病毒主要通过呼吸道飞沫传播和密切接触传播。飞沫传播发生在人们咳嗽、打喷嚏或讲话时，病毒通过飞沫进入他人呼吸道。接触传播则是通过接触含病毒的表面，然后触摸口鼻眼等部位。此外，一些研究表明，气溶胶传播和粪口传播也可能在特定条件下发生。

症状表现：
感染新型冠状病毒后，患者可能会出现发热、干咳、乏力、咽痛、肌肉疼痛等症状，部分患者可能出现嗅觉或味觉丧失、腹泻等非典型症状。重症患者可能发展为肺炎、急性呼吸窘迫综合征（ARDS）、多器官功能衰竭，甚至导致死亡。老年人和有基础疾病的人群，如糖尿病、高血压和心血管疾病患者，患重症的风险更高。

 防控措施
应对新型冠状病毒的传播，公共卫生措施包括：
1. 保持社交距离：避免大型聚集，保持1米以上的安全距离。
2. 佩戴口罩：尤其是在密闭空间和人群密集场所。
3. 勤洗手：使用肥皂和清水或含酒精的洗手液。
4. 加强通风：保持室内空气流通。
5. 接种疫苗：疫苗接种被证明是降低感染率和重症率的有效手段。

疫情的全球影响：
自疫情爆发以来，新冠病毒迅速扩散，导致全球数百万人感染，并对经济、医疗系统和社会生活造成巨大冲击。各国采取了封锁、旅行限制和大规模检测等措施应对疫情，同时也加速了疫苗和治疗药物的研发。尽管目前全球疫情已逐步得到控制，但病毒的变异和反复传播仍对公共卫生系统构成挑战。

展望：
未来，人类仍需与新型冠状病毒长期共存。加强病毒监测、优化治疗手段、提升疫苗接种覆盖率以及普及公共卫生知识，是应对新冠疫情和类似新发传染病的重要举措。通过全球合作，最终实现控制疫情的目标仍然值得期待。",style = 'text-align:justify;'),
          p(" ",style = 'text-align:justify;'),
          tags$br(),
          p("该监测器的开发目的是让每个人都能获得 COVID-19 趋势的数据和关键可视化效果，同时也提供一个使用数据专业预测分析的平台。其中各国预测是基于215个国家或地区数据得来，个体预测模型基于60万个个体得来",style = 'text-align:justify;')
        ),
        argonColumn(
          width = 3,
          img(src = '防治.gif',width = "100%",height = "60%"),
          h6("来源: Harvard Medical School",style = 'text-align:center;font-style: italic;font-weight: bold;')
        )
        
          ),
      p(" ",style = 'text-align:justify;'),
      tags$br(),
      h4("Important Note:",style = 'color:Red;font-size:15px;text-align:Left;'),
      p("1. 使用的数据取自世卫组织网站。如有任何数字差异，请联系开发人员yangboran97@163.com。",style = 'color:Red;font-size:13px;text-align:Left;'),
      p(paste0("2. 数据将在格林威治标准时间 00:00 每天更新。每日数字可能与您当地的来源不匹配，但汇总数字肯定会匹配。"),style = 'color:Red;font-size:13px;text-align:Left;'),
      p(paste0("3. 最近更新时间: ",lastUpdate),style = 'color:Red;font-size:13px;text-align:Left;')
      
      
    ),
    # analysis setting tab -----
    argonTab(
      tabName = "各国或地区数据可视化",
      active = F,
      tags$head(tags$style(type = "text/css", "
             #loadmessage {
                           position: fixed;
                           top: 150px;
                           left: 50px;
                           width: 93%;
                           padding: 5px 0px 5px 0px;
                           text-align: center;
                           font-weight: bold;
                           font-size: 100%;
                           color: #000000;
                           background-color: #CCFF66;
                           z-index: 105;
}
  ")),
      argonRow(
        argonColumn(
          width = 12,
          uiOutput("cardUI") %>% withSpinner()
        )
      ),
      tags$hr(),
      argonRow(
        argonColumn(
          width = 12,
          uiOutput("chartUI") %>% withSpinner()
        )
      ),
      conditionalPanel(condition = "$('html').hasClass('shiny-busy')",
                       tags$div("正在加载页面!!!请稍候...",id = "loadmessage")),
      argonRow(
        argonColumn(
          width = 12,
          dataTableOutput("dataTableCountryWise") %>% withSpinner()
          
        )
      )
    ),
  argonTab(
    tabName = "国家或地区间比较",
    active = F,
    uiOutput("countryComparisionChartsUI") %>% withSpinner(),
    tags$hr(),
    argonRow(
      argonColumn(
        width = 12,
        dataTableOutput("dataTableCountryCompare") %>% withSpinner()
        
      )
    )
  ),
  argonTab(
    tabName = "国家或地区预测",
    active = F,
    uiOutput("forecastUI") %>% withSpinner()
  ),
  argonTab(
    tabName = "个体预测",
    active = F,
    uiOutput("predictionUI") %>% withSpinner()
    
  )
  # argonTab(
  #   tabName = "Debug",
  #   active = T,
  #   icon =  icon("wrench"),
  #   tagList(
  #       argonRow(
  #         argonColumn(
  #           width =  12,
  #           argonRow(
  #             argonColumn(
  #               width =  12,
  #               textInput(
  #                 "runRCode",
  #                 paste0("Run R code",ifelse(Production," (disabled in production version)","")),
  #                 width = "100%"
  #               )
  #             )
  #           ),
  #           argonRow(
  #             argonColumn(
  #               width =  12,
  #               actionButton("runRCodeButton","Submit code")
  #             )
  #           )
  #         )
  #       ),
  #       argonRow(
  #         argonColumn(
  #           width =  12,
  #           br(),
  #           verbatimTextOutput("runRCodeOutput")
  #         )
  #       )
  #   )
  # )
  )
})

outputOptions(output, "dashboard", suspendWhenHidden = FALSE)

output$confirmedCount <- renderCountup({
  results$dataframeFinal = coronavirus
  dataframeTotal <- coronavirus %>% 
    dplyr::group_by(countryName) %>%
    slice(n()) %>%
    ungroup() %>%
    dplyr::mutate(Unrecovered = Confirmed - ifelse(is.na(Recovered), 0, Recovered) - ifelse(is.na(Deaths), 0, Deaths)) %>%
    dplyr::arrange(-Confirmed) %>%
    dplyr::ungroup() %>%
    select(-c(date,region,lat,lon))
  # browser()
  results$dataframeTotal = dataframeTotal
  totalConfirmed = sum(results$dataframeTotal$Confirmed,na.rm = T)
  opts <- list(useEasing = TRUE,
               useGrouping = TRUE,
               prefix = "确诊人数： ")
  countup(
    totalConfirmed,
    start_at = 0,
    options = opts,
    duration = 2,
    start = TRUE,
    width = "100%",
    height = NULL,
    elementId = NULL
  )
})
output$activeCount <- renderCountup({
  totalUnrecovered = sum(results$dataframeTotal$Unrecovered,na.rm = T)
  totalConfirmed = sum(results$dataframeTotal$Confirmed,na.rm = T)
  activeCasesPer = round(((totalUnrecovered/totalConfirmed)*100),1)
  opts <- list(useEasing = TRUE,
               useGrouping = TRUE,
               prefix = "感染人数：",
               suffix = paste0(" (",activeCasesPer,"%)")
  )
  countup(
    totalUnrecovered,
    start_at = 0,
    options = opts,
    duration = 2,
    start = TRUE,
    width = "100%",
    height = NULL,
    elementId = NULL
  )
})
output$recoveredCount <- renderCountup({
  totalRecovered = sum(results$dataframeTotal$Recovered,na.rm = T)
  totalConfirmed = sum(results$dataframeTotal$Confirmed,na.rm = T)
  totalRecoveredPer = round(((totalRecovered/totalConfirmed)*100),1)
  opts <- list(useEasing = TRUE,
               useGrouping = TRUE,
               prefix = "康复人数：",
               suffix = paste0(" (",totalRecoveredPer,"%)")
               )
  countup(
    totalRecovered,
    start_at = 0,
    options = opts,
    duration = 2,
    start = TRUE,
    width = "100%",
    height = NULL,
    elementId = NULL
  )
})
output$deathCount <- renderCountup({
  totalDeath = sum(results$dataframeTotal$Deaths,na.rm = T)
  totalConfirmed = sum(results$dataframeTotal$Confirmed,na.rm = T)
  totalDeathPer = round(((totalDeath/totalConfirmed)*100),1)
  opts <- list(useEasing = TRUE,
               useGrouping = TRUE,
               prefix = "死亡人数：",
               suffix = paste0(" (",totalDeathPer,"%)"))
  countup(
    totalDeath,
    start_at = 0,
    options = opts,
    duration = 2,
    start = TRUE,
    width = "100%",
    height = NULL,
    elementId = NULL
  )
})
output$countryCount <- renderCountup({
  x = results$dataframeTotal %>%
      filter(Confirmed > 0) %>%
      select(countryName) %>%
      unique() %>%                                                                              nrow()
  opts <- list(useEasing = TRUE,
               useGrouping = TRUE,
               prefix = "世界各国感染总数: "
              )
  countup(
    x,
    start_at = 0,
    options = opts,
    duration = 2,
    start = TRUE,
    width = "100%",
    height = NULL,
    elementId = NULL
  )
})

output$cardUI = renderUI({
  df_daily <- coronavirus %>% 
    dplyr::group_by(date) %>%
    dplyr::summarise(totalConfirmed = sum(Confirmed, na.rm = TRUE),
                     totalRecovered = sum(Recovered,na.rm = TRUE),
                     totalDeaths = sum(Deaths,na.rm = T)
    ) %>%
    dplyr::arrange(date) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(totalUnrecovered = totalConfirmed - totalRecovered - totalDeaths) 
  results$dfDaily = df_daily
  
  max_date <- as.Date(max(coronavirus$date)) 
  newCases = coronavirus %>% 
    dplyr::filter(date == max_date | date == max_date - 1) %>%
    dplyr::group_by(countryName) %>%
    mutate(ConfirmedNew = Confirmed - shift(Confirmed,1)) %>% 
    mutate(RecoveredNew = Recovered - shift(Recovered,1)) %>%
    mutate(DeathsNew = Deaths - shift(Deaths,1)) %>%
    slice(n()) %>%
    ungroup() %>%
    select(countryName,ConfirmedNew,RecoveredNew,DeathsNew)
  
  results$newCases = newCases
  dataframeTotalOldCases = coronavirus %>%
    dplyr::filter(date == max_date - 1) %>%
    dplyr::mutate(Unrecovered = Confirmed - Recovered - Deaths) %>%
    summarise(totalConfirmed = sum(Confirmed,na.rm = T),
              totalDeath = sum(Deaths,na.rm = T),
              totalRecovered = sum(Recovered,na.rm = T),
              totalUnrecovered = sum(Unrecovered,na.rm = T)
    )
  results$dataframeTotalOldCases = dataframeTotalOldCases
  dataframeOldCases = coronavirus %>%
    dplyr::filter(date == max_date - 1) %>%
    dplyr::mutate(Unrecovered = Confirmed - Recovered - Deaths)
  results$dataframeOldCases = dataframeOldCases
  tagList(
    argonRow(
      argonColumn(
        width = 12,
        center = T,
        argonBadge(text = countupOutput("countryCount"), 
                   src = NULL, 
                   pill = T, 
                   status = "danger")
       )
      ),
      tags$br(),
    argonRow(
      argonColumn(
        width = 3,
        argonInfoCard(
          value = countupOutput("confirmedCount"),
          icon = icon("users"),
          icon_background = "default",
          hover_lift = F,
          shadow = T,
          background_color = "warning",
          gradient = T,
          width = 12
        ),
        h6(paste0("昨日汇总: ",
                  prettyNum(results$dataframeTotalOldCases$totalConfirmed,big.mark = ",")
                  ), 
                  style = 'text-align:center;
                           font-size:15px;')
      ),
      argonColumn(
        width = 3,
        argonInfoCard(
          value = countupOutput("activeCount"),
          icon = icon("hospital"),
          icon_background = "default",
          hover_lift = F,
          shadow = T,
          background_color = "info",
          gradient = T,
          width = 12
        ),
        h6(paste0("昨日汇总: ",
                  prettyNum(results$dataframeTotalOldCases$totalUnrecovered,big.mark = ",")
                  ), 
                  style = 'text-align:center;
                           font-size:15px;')
      ),
      argonColumn(
        width = 3,
        argonInfoCard(
          value = countupOutput("recoveredCount"),
          icon = icon("smile"),
          icon_background = "default",
          hover_lift = F,
          shadow = T,
          background_color = "success",
          gradient = T,
          width = 12
        ),
        h6(paste0("昨日汇总: ",
                  prettyNum(results$dataframeTotalOldCases$totalRecovered,big.mark = ",")
                  ), 
                  style = 'text-align:center;
                           font-size:15px;')
      ),
      argonColumn(
        width = 3,
        argonInfoCard(
          value = countupOutput("deathCount"),
          icon = icon("heartbeat"),
          icon_background = "default",
          hover_lift = F,
          shadow = T,
          background_color = "danger",
          gradient = T,
          width = 12
        ),
        h6(paste0("昨日汇总: ",
                  prettyNum(results$dataframeTotalOldCases$totalDeath,big.mark = ",")
                  ), 
                  style = 'text-align:center;
                           font-size:15px;')
      )
    )
  )
})

output$chartUI = renderUI({
  tagList(
  argonRow(
    argonColumn(
      width = 6,
      argonRow(
        argonColumn(
          width = 3,
          tags$strong("汇总结果")
        ),
        argonColumn(
          width = 1,
          dropdownButton(
            tagList(
              prettyRadioButtons(
                inputId = "aggregatePlotOptions",
                label = NULL,
                choices = setNames(c(1:5),c("总例数",
                                            "累计病例",
                                            paste0("确诊新病例 (",Sys.Date() - 1,")"),
                                            paste0("死亡人数 (",Sys.Date() - 1,")"),
                                            paste0("康复人数 (",Sys.Date() - 1,")")
                                            )
                                   ),
                selected = "1",
                shape = c("round"),
                outline = T,
                fill = T,
                width = "100%"
              )
            ),
            status = "primary",
            size = "sm",
            circle = T,
            icon = icon("wrench"),
            right = T,
            margin = "10px",
            inputId = "aggregatePlotOptionsDropdown"
          ),
          bsPopover("aggregatePlotOptionsDropdown", title = NULL, content = "单击以指定绘图类型", placement = "left", trigger = "hover",
                    options = NULL)
        )
      ),
      argonRow(
        argonColumn(
          width = 12,
          div(
            id = "totalCasesPlotDiv",
            highchartOutput("totalCasesPlot",width = "100%") %>% withSpinner()
          ),
          div(
            id = "cumulativePlotDiv",
            highchartOutput("cumulativePlot",width = "100%") %>% withSpinner()
          ),
          div(
            id = "newCasesPlotDiv",
            highchartOutput("newCasesPlot",width = "100%") %>% withSpinner()
          ),
          div(
            id = "newCasesDeathsPlotDiv",
            highchartOutput("newCasesDeathsPlot",width = "100%") %>% withSpinner()
          ),
          div(
            id = "newCasesRecoveredPlotDiv",
            highchartOutput("newCasesRecoveredPlot",width = "100%") %>% withSpinner()
          )
        )
      )
    ),
    argonColumn(
      width = 6,
      argonRow(
        argonColumn(
          width = 8,
          tags$strong("点击某个国家/地区即可查看特定国家/地区的结果")
        ),
        argonColumn(
          width = 1,
          dropdownButton(
            tagList(
              prettyRadioButtons(
                inputId = "highchartOption",
                label = NULL,
                choices = setNames(c(1:4),c("总病例","康复病例","死亡病例","现有病例")),
                selected = "1",
                shape = c("round"),
                outline = T,
                fill = T,
                width = "100%"
              )
            ),
            status = "primary",
            size = "sm",
            circle = T,
            icon = icon("wrench"),
            right = T,
            margin = "10px",
            inputId = "worldMapOption"
          ),
          bsPopover("worldMapOption", title = NULL, content = "点击指定结果", placement = "left", trigger = "hover",
                    options = NULL)
        )
      ),
      highchartOutput("worldMap",width = "100%") %>% withSpinner()
    )
  ),
  tags$hr(),
  argonRow(

  )
  )

})

output$worldMap <- renderHighchart({
  req(!is.null(results$dataframeTotal))
  canvasClickFunction <- JS("function(event) {Shiny.setInputValue('canvasClicked', [event.point.name]);}")
  x = input$highchartOption %>% as.numeric()
  data = results$dataframeTotal 
  # %>% 
  #        filter(str_detect(tolower(countryName), pattern = paste(y,collapse = "|"))) 
  value = switch(x,"Confirmed","Recovered","Deaths","Unrecovered")
  colnames(data)[5] = "name"
  highchart(type = "map",width = "100%",height = "100%") %>%
    hc_add_series_map(map = worldgeojson, df = data, value = value, joinBy = "name") %>%
    hc_colorAxis(stops = color_stops(5)) %>%
    hc_tooltip(useHTML = TRUE,
               headerFormat = '',
               pointFormat = paste0('{point.name}: {point.',value,'} ')) %>%
    hc_exporting(enabled = TRUE,filename = value) %>% 
    hc_add_theme(hc_theme_ffx()) %>%
    hc_chart(zoomType = "xy") %>%
    hc_mapNavigation(enabled = TRUE) %>%
    hc_plotOptions(series = list( 
      events = list(click = canvasClickFunction),allowPointSelect = T))
})

output$cumulativePlot = renderHighchart({
  confirmed_color = "#172b4d"
  active_color <- "#1f77b4"
  recovered_color <- "forestgreen"
  death_color <- "red"
  df_daily = results$dfDaily
  x = max(df_daily$totalConfirmed,df_daily$totalUnrecovered,df_daily$totalDeaths,df_daily$totalRecovered)
  y = nchar(x) - 1
  yLimit = x %>% round(-y)
  hc <- highchart() %>% 
    hc_subtitle(text = "Cumulative Cases",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = df_daily$date) %>%
    hc_yAxis(title = list(text = "Cumulative Number of Cases")) %>%
    hc_add_series(name = "确诊病例",data = df_daily$totalConfirmed) %>% 
    hc_add_series(name = "现有病例",data = df_daily$totalUnrecovered) %>% 
    hc_add_series(name = "康复病例", data = df_daily$totalRecovered) %>% 
    hc_add_series(name = "死亡病例", data = df_daily$totalDeaths)
  
  hc %>% 
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_exporting(
      enabled = TRUE
    ) %>%
    hc_colors(c(confirmed_color,active_color, recovered_color ,death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})

output$totalCasesPlot = renderHighchart({
  x = results$dataframeTotal %>%
        select(-countryCode) %>%
        arrange(desc(Confirmed)) %>%
        .[1:10,]
  confirmed_color = "#172b4d"
  active_color <- "#1f77b4"
  recovered_color <- "forestgreen"
  death_color <- "red"
  hc <- highchart() %>% 
    hc_subtitle(text = "感染总数（前 10 个国家）",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = x$countryName) %>%
    hc_yAxis(title = list(text = "例数 (Log scale)"),type = "logarithmic") %>%
    hc_add_series(name = "确诊病例",data = x$Confirmed) %>% 
    hc_add_series(name = "现有病例",data = x$Unrecovered) %>% 
    hc_add_series(name = "康复病例", data = x$Recovered) %>% 
    hc_add_series(name = "死亡病例", data = x$Deaths)
  hc %>% 
    hc_chart(type = "column") %>%
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_exporting(
      enabled = TRUE
    ) %>%
    hc_colors(c(confirmed_color,active_color, recovered_color ,death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})

output$newCasesPlot = renderHighchart({
  x = results$newCases %>%
        select(countryName,ConfirmedNew) %>%
        arrange(-ConfirmedNew) %>%
        top_n(n = 25,wt = ConfirmedNew)
  death_color <- "orange"
  hc <- highchart() %>% 
    hc_subtitle(text = "New  Cases (Top 25 countries)",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = x$countryName,title = list(text = "Countries")) %>%
    hc_yAxis(title = list(text = "New Cases")) %>%
    hc_add_series(name = "Cases:",
                  data = x$ConfirmedNew,
                  showInLegend = F) 
  
  hc %>% 
    hc_chart(type = "column") %>%
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_exporting(
      enabled = TRUE
    ) %>%
    hc_colors(c(death_color)) %>%
    hc_tooltip(shared = TRUE, borderWidth = 5,table = F)
})
output$newCasesDeathsPlot = renderHighchart({
  x = results$newCases %>%
        select(countryName,DeathsNew) %>%
        arrange(-DeathsNew) %>%
        top_n(n = 25,wt = DeathsNew)
  death_color <- "red"
  hc <- highchart() %>% 
    hc_subtitle(text = "New Deaths (Top 25 countries)",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = x$countryName) %>%
    hc_yAxis(title = list(text = "New Deaths")) %>%
    hc_add_series(name = "Cases:",
                  data = x$DeathsNew,
                  showInLegend = F) 
  
  hc %>% 
    hc_chart(type = "column") %>%
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_exporting(
      enabled = TRUE
    ) %>%
    hc_colors(c(death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})
output$newCasesRecoveredPlot = renderHighchart({
  x = results$newCases %>%
        select(countryName,RecoveredNew) %>%
        arrange(-RecoveredNew) %>%
        top_n(n = 25,wt = RecoveredNew)
  death_color <- "green"
  hc <- highchart() %>% 
    hc_subtitle(text = "Newly Recovered (Top 25 countries)",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = x$countryName) %>%
    hc_yAxis(title = list(text = "New Recovered")) %>%
    hc_add_series(name = "Cases:",
                  data = x$RecoveredNew,
                  showInLegend = F) 
  
  hc %>% 
    hc_chart(type = "column") %>%
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_colors(c(death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})

output$dataTableCountryWise = renderDataTable({
  req(!is.null(results$dataframeTotal))
  x = results$dataframeTotal %>%
        select(-countryCode) %>%
        arrange(desc(Confirmed)) %>%
        mutate(totalActivePer = Unrecovered/Confirmed) %>%
        mutate(totalRecoveredPer = Recovered/Confirmed) %>%
        mutate(totalDeathPer = Deaths/Confirmed) %>%
    select(Country = countryName, 确诊病例 = Confirmed, 现有病例 = Unrecovered,康复病例 = Recovered,死亡病例 = Deaths,"感染率(%)" = totalActivePer,"康复率(%)" = totalRecoveredPer,"死亡率(%)" = totalDeathPer)
  results$resultTable = x
  datatable(x,
            extensions = 'Buttons',
            rownames = FALSE,
            filter = 'top',
            options = list(
              searchHighlight = TRUE,
              pageLength = 25,
              scrollX = TRUE,
              dom = 'Bfrtip',
              buttons =
                list(
                  list(
                    extend = 'collection',
                    buttons = c('csv', 'pdf'),
                    text = '下载文件'
                  )
                )
              
            )
            
  ) %>%
  formatPercentage('感染率(%)',2) %>%
  formatPercentage('康复率(%)',2) %>%
  formatPercentage('死亡率(%)',2) %>%
  formatStyle(
      '感染率(%)',
      background = styleColorBar(x$'感染率(%)', '#31bed4'),
      backgroundSize = '100% 90%',
      backgroundRepeat = 'no-repeat',
      backgroundPosition = 'center'
    ) %>%
    formatStyle(
      '康复率(%)',
      background = styleColorBar(x$'康复率(%)', '#8bd431'),
      backgroundSize = '100% 90%',
      backgroundRepeat = 'no-repeat',
      backgroundPosition = 'center'
    ) %>%
    formatStyle(
      '死亡率(%)',
      background = styleColorBar(x$'死亡率(%)', '#ff5757'),
      backgroundSize = '100% 90%',
      backgroundRepeat = 'no-repeat',
      backgroundPosition = 'center'
    )
})

#### Country Specific tab

countrySpecificModal <- function(){
  countryName = input$canvasClicked
  x = results$dataframeTotal %>% 
          filter(countryName == input$canvasClicked)
  totalConfirmed = x$Confirmed
  totalConfirmedYesterday = results$dataframeOldCases %>%
                                filter(countryName == input$canvasClicked) %>%
                                .["Confirmed"]
  totalUnrecovered = x$Unrecovered
  activeCasesPer = round(((totalUnrecovered/totalConfirmed)*100),1)
  yesterdayActiveCountry = results$dataframeOldCases %>%
                                filter(countryName == input$canvasClicked) %>%
                                .["Unrecovered"]
  totalRecovered = x$Recovered
  totalRecoveredPer = round(((totalRecovered/totalConfirmed)*100),1)
  yesterdayRecoveredCountry = results$dataframeOldCases %>%
                                  filter(countryName == input$canvasClicked) %>%
                                  .["Recovered"]
  totalDeath = x$Deaths
  totalDeathPer = round(((totalDeath/totalConfirmed)*100),1)
  yesterdayDeathsCountry = results$dataframeOldCases %>%
                              filter(countryName == input$canvasClicked) %>%
                              .["Deaths"]
  modalDialog(
  tagList(
    argonRow(
      argonColumn(
        center = T,
        width = 12,
        h1(countryName)
      )
    ),
    argonRow(
      argonColumn(
        width = 3,
        argonBadge(text = paste0("Confirmed: ",prettyNum(totalConfirmed,big.mark = ",")), 
                   src = NULL, 
                   pill = T, 
                   status = "warning"),
          h6(paste0("Yesterday:",
                    prettyNum(totalConfirmedYesterday,
                              big.mark = ",")
          ),
          style = 'text-align:center;
          font-size:15px;')
      ),
      argonColumn(
        width = 3,
        argonBadge(text = paste0("Active:",prettyNum(totalUnrecovered,big.mark = ",")
                                 # " (",activeCasesPer,"%)"
                                 ), 
                   src = NULL, 
                   pill = T, 
                   status = "info"),
        h6(paste0("Yesterday:",
                  prettyNum(yesterdayActiveCountry,
                            big.mark = ",")
        ),
        style = 'text-align:center;
        font-size:15px;')
        ),
      argonColumn(
        width = 3,
        argonBadge(text = paste0("Recovered: ",prettyNum(totalRecovered,big.mark = ",")
                                 # " (",totalRecoveredPer,"%)"
                                 ), 
                   src = NULL, 
                   pill = T, 
                   status = "success"),
        h6(paste0("Yesterday:",
                  prettyNum(yesterdayRecoveredCountry,
                            big.mark = ",")
        ),
        style = 'text-align:center;
        font-size:15px;')
        ),
      argonColumn(
        width = 3,
        argonBadge(text = paste0("Deaths:",prettyNum(totalDeath,big.mark = ",")
                                 # " (",totalRecoveredPer,"%)"
        ), 
        src = NULL, 
        pill = T, 
        status = "danger"),
        h6(paste0("Yesterday:",
                  prettyNum(yesterdayDeathsCountry,
                            big.mark = ",")
        ),
        style = 'text-align:center;
        font-size:15px;')
        )
    ),
    tags$hr(),
    argonRow(
    argonColumn(
      width = 12,
      argonRow(
        argonColumn(
          width = 5,
          # tags$strong("Country specific plots"),
          dateRangeInput( inputId = "dateRange", 
                         label = NULL,
                         start = min(coronavirus$date),
                         end   = Sys.Date() - 1,
                         min = min(coronavirus$date),
                         max   = Sys.Date() - 1,
                         format = "dd-mm-yyyy",
                         width = "100%"
                         )
        ),
        argonColumn(
          width = 4,
          prettySwitch(inputId = "scaleCountry",
                       label = "Logarithmic Scale",
                       value = F,
                       status = "primary",
                       fill = T,
                       inline = T,
                       width = "100%"
                       )
        ),
        argonColumn(
          width = 1,
          offset = 1,
          dropdownButton(
            tagList(
              prettyRadioButtons(
                inputId = "countryPlotOptions",
                label = NULL,
                choices = setNames(c(1:4),c("Cumulative Cases",
                                            paste0("Confirmed New Cases (",Sys.Date() - 1,")"),
                                            paste0("Deaths (",Sys.Date() - 1,")"),
                                            paste0("Recovered (",Sys.Date() - 1,")")
                )
                ),
                selected = "1",
                shape = c("round"),
                outline = T,
                fill = T,
                width = "100%"
              )
            ),
            status = "primary",
            size = "sm",
            circle = T,
            icon = icon("wrench"),
            right = T,
            margin = "10px",
            inputId = "countryPlotOptionsDropdown"
          ),
          bsPopover("countryPlotOptionsDropdown", title = NULL, content = "Click to specify the type of plot", placement = "left", trigger = "hover",
                    options = NULL)
        )
      ),
      argonRow(
        argonColumn(
          width = 12,
          div(
            id = "cumulativeCountryPlotDiv",
            highchartOutput("cumulativeCountryPlot",width = "100%") %>% withSpinner()
          ),
          hidden(
            div(
            id = "newCasesCountryPlotDiv",
            highchartOutput("newCasesCountryPlot",width = "100%") %>% withSpinner()
           )
          ),
          hidden(
            div(
            id = "newCasesDeathsCountryPlotDiv",
            highchartOutput("newCasesDeathCountryPlot",width = "100%") %>% withSpinner()
          )
          ),
          hidden(
            div(
            id = "newCasesRecoveredCountryPlotDiv",
            highchartOutput("newCasesRecoveredCountryPlot",width = "100%") %>% withSpinner()
          )
          )
        )
      )
     )
    )
  ),
  title = NULL,
  size = "l", 
  align = "center",
  easyClose = TRUE,
  fade = T, 
  footer = NULL
)
}


output$cumulativeCountryPlot = renderHighchart({
  confirmed_color = "#172b4d"
  active_color <- "#1f77b4"
  recovered_color <- "forestgreen"
  death_color <- "red"
  df_daily <- coronavirus %>% 
                filter(countryName == input$canvasClicked) %>%
                dplyr::group_by(date) %>%
                dplyr::summarise(totalConfirmed = sum(Confirmed, na.rm = TRUE),
                                 totalRecovered = sum(Recovered,na.rm = TRUE),
                                 totalDeaths = sum(Deaths,na.rm = T)
                ) %>%
                dplyr::arrange(date) %>%
                dplyr::ungroup() %>%
                dplyr::mutate(totalUnrecovered = totalConfirmed - totalRecovered - totalDeaths) %>%
                filter(date >= input$dateRange[1] & date <= input$dateRange[2])
  scale = ifelse(input$scaleCountry,"logarithmic","linear")
  hc <- highchart() %>% 
    hc_subtitle(text = paste0("Cumulative Cases in ",input$countrySelect),
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = df_daily$date) %>%
    hc_yAxis(title = list(text = "Cumulative Number of Cases"),type = scale) %>%
    hc_add_series(name = "Confirmed",data = df_daily$totalConfirmed) %>% 
    hc_add_series(name = "Active",data = df_daily$totalUnrecovered) %>% 
    hc_add_series(name = "Recovered", data = df_daily$totalRecovered) %>% 
    hc_add_series(name = "Death", data = df_daily$totalDeaths)
  
  hc %>% 
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_colors(c(confirmed_color,active_color, recovered_color ,death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})

output$newCasesCountryPlot = renderHighchart({
  newCases = results$dataframeFinal %>% 
              select(date,countryName,Confirmed) %>%
              dplyr::filter(countryName == input$canvasClicked) %>%
              mutate(confirmedDaily = if_else(is.na(Confirmed - shift(Confirmed,1)),
                                      Confirmed,
                                      Confirmed - shift(Confirmed,1)
                                      )
                     
                     ) %>% 
              filter(date >= input$dateRange[1] & date <= input$dateRange[2])
  scale = ifelse(input$scaleCountry,"logarithmic","linear") 
  x = newCases
  death_color <- "orange"
  hc <- highchart() %>% 
    hc_subtitle(text = "Confirmed cases",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = x$date) %>%
    hc_yAxis(title = list(text = "New Cases"),type = scale) %>%
    hc_add_series(name = "Countries",data = x$confirmedDaily) 
  
  hc %>% 
    hc_chart(type = "Recoverd") %>%
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_colors(c(death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})

output$newCasesDeathCountryPlot = renderHighchart({
  newCases = results$dataframeFinal %>% 
                select(date,countryName,Deaths) %>%
                dplyr::filter(countryName == input$canvasClicked) %>%
                mutate(deathDaily = if_else(is.na(Deaths - shift(Deaths,1)),
                                            Deaths,
                                            Deaths - shift(Deaths,1)
                )
                
                ) %>% 
                filter(date >= input$dateRange[1] & date <= input$dateRange[2])
  scale = ifelse(input$scaleCountry,"logarithmic","linear")
  x = newCases
  death_color <- "red"
  hc <- highchart() %>% 
    hc_subtitle(text = "Deaths",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = x$date) %>%
    hc_yAxis(title = list(text = "Deaths"), type = scale) %>%
    hc_add_series(name = "Countries",data = x$deathDaily) 
  
  hc %>% 
    hc_chart(type = "column") %>%
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_colors(c(death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})

output$newCasesRecoveredCountryPlot = renderHighchart({
  newCases = results$dataframeFinal %>% 
                select(date,countryName,Recovered) %>%
                dplyr::filter(countryName == input$canvasClicked) %>%
                mutate(recoveredDaily = if_else(is.na(Recovered - shift(Recovered,1)),
                                            Recovered,
                                            Recovered - shift(Recovered,1)
                )
                
                ) %>% 
                filter(date >= input$dateRange[1] & date <= input$dateRange[2])
  scale = ifelse(input$scaleCountry,"logarithmic","linear")
  x = newCases
  death_color <- "green"
  hc <- highchart() %>% 
    hc_subtitle(text = "Recovered",
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = x$date) %>%
    hc_yAxis(title = list(text = "Recovered"),type = scale) %>%
    hc_add_series(name = "Countries",data = x$recoveredDaily) 
  
  hc %>% 
    hc_chart(type = "column") %>%
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_colors(c(death_color)) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
})

#### Country Comparision tab ----

output$countryComparisionChartsUI = renderUI({
  tagList(
    argonRow(
      argonColumn(
        width = 12,
        selectInput(
          inputId = "countryCompareList",
          label = strong("选择您想要在图表中比较的国家或地区"),
          choices = results$dataframeTotal$countryName,
          selected = results$dataframeTotal$countryName[c(35:45)],
          selectize = F,
          multiple = T,
          width = "100%"
        )
      ),
      argonColumn(
        width = 3,
        dropdownButton(
          prettyRadioButtons(
            inputId = "countryCompareTypeofPlot",
            label = NULL,
            choices = setNames(c(1:5),c("累计病例",
                                        "确诊病例",
                                        "现有病例",
                                        "康复病例",
                                        "死亡病例")),
            selected = "1",
            shape = c("round"),
            outline = T,
            fill = T,
            width = "100%"
          ),
          label = "比较结果：",
          status = "primary",
          circle = F,
          icon = icon("wrench"),
          right = T,
          margin = "10px",
          inputId = "countryCompareTypeofPlotDropdown"
        )
      ),
      argonColumn(
        width = 4,
        dateRangeInput( inputId = "dateRangeCompare", 
                        label = NULL,
                        start = min(coronavirus$date),
                        end   = Sys.Date() - 1,
                        min = min(coronavirus$date),
                        max   = Sys.Date() - 1,
                        format = "dd-mm-yyyy",
                        width = "100%"
        )
      ),
      argonColumn(
        width = 2,
        offset = 3,
        prettySwitch(inputId = "scaleCountryCompare",
                     label = "Logarithmic Scale",
                     value = F,
                     status = "primary",
                     fill = T,
                     inline = T,
                     width = "100%"
        )
      )
    ),
    tags$hr(),
    argonRow(
      argonColumn(
        width = 12,
        highchartOutput("countryCompareChart") %>% withSpinner()
      )
    )
  )
})

output$countryCompareChart = renderHighchart({
  req(!is.null(input$countryCompareList))
  countryList = input$countryCompareList
  scale = ifelse(input$scaleCountryCompare,"logarithmic","linear")
  dateRange = input$dateRangeCompare
  plotType = switch(as.numeric(input$countryCompareTypeofPlot),
                    "Cumulative",
                    "Confirmed",
                    "Active",
                    "Recovered",
                    "Deaths")
  if (plotType != "Cumulative") {
    data =  coronavirus %>%
      filter(countryName %in% countryList) %>%
      filter(date >= dateRange[1] & date <= dateRange[2]) %>%
      mutate(Active = Confirmed - Recovered - Deaths) %>%
      select(date,countryName,plotType)
    hc <- highchart() %>% 
      hc_subtitle(text = paste0("Comparing ",plotType," cases for ",length(countryList)," countries"),
                  align = "left",
                  style = list(color = "#2b908f", fontWeight = "bold")) %>%
      hc_xAxis(categories = data$date) %>%
      hc_yAxis(title = list(text = paste0(plotType," cases")),
               type = scale)
    for (i in 1:length(countryList)) {
      hc = hc_add_series(hc,
                         name = countryList[i],
                         data = data %>%
                           filter(countryName == countryList[i]) %>%
                           .[,3]
      )
    }
    hc %>% 
      hc_chart(borderColor = '#EBBA95',
               borderRadius = 10,
               borderWidth = 2
      ) %>%
      hc_exporting(
        enabled = TRUE
      ) %>%
      hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
                 shared = TRUE, borderWidth = 5,table = T)
  } else {
    data = results$dataframeTotal %>%
      filter(countryName %in% countryList)
    confirmed_color = "#172b4d"
    active_color <- "#1f77b4"
    recovered_color <- "forestgreen"
    death_color <- "red"
    hc <- highchart() %>% 
      hc_subtitle(text = paste0("Comparing ",length(countryList)," countries"),
                  align = "left",
                  style = list(color = "#2b908f", fontWeight = "bold")) %>%
      hc_xAxis(categories = data$countryName) %>%
      hc_yAxis(title = list(text = "总病例"),type = scale) %>%
      hc_add_series(name = "确诊",data = data$Confirmed) %>% 
      hc_add_series(name = "已有",data = data$Unrecovered) %>% 
      hc_add_series(name = "康复", data = data$Recovered) %>% 
      hc_add_series(name = "死亡", data = data$Deaths)
    hc %>% 
      hc_chart(type = "column") %>%
      hc_chart(borderColor = '#EBBA95',
               borderRadius = 10,
               borderWidth = 2
      ) %>%
      hc_exporting(
        enabled = TRUE
      ) %>%
      hc_colors(c(confirmed_color,active_color, recovered_color ,death_color)) %>%
      hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
                 shared = TRUE, borderWidth = 5,table = T)
  }
  
})

output$dataTableCountryCompare = renderDataTable({
  req(!is.null(input$countryCompareList))
  countryList = input$countryCompareList
  x = results$dataframeTotal %>%
    filter(countryName %in% countryList) %>%
    select(-countryCode) %>%
    arrange(desc(Confirmed)) %>%
    mutate(totalActivePer = Unrecovered/Confirmed) %>%
    mutate(totalRecoveredPer = Recovered/Confirmed) %>%
    mutate(totalDeathPer = Deaths/Confirmed) %>%
    select(Country = countryName, 确诊病例 = Confirmed, 现有病例 = Unrecovered,康复病例 = Recovered,死亡病例 = Deaths,"感染率(%)" = totalActivePer,"康复率(%)" = totalRecoveredPer,"死亡率(%)" = totalDeathPer)
  datatable(x,
            extensions = 'Buttons',
            rownames = FALSE,
            filter = 'top',
            options = list(
              searchHighlight = TRUE,
              pageLength = 25,
              scrollX = TRUE,
              dom = 'Bfrtip',
              buttons =
                list(
                  list(
                    extend = 'collection',
                    buttons = c('csv', 'pdf'),
                    text = 'Download'
                  )
                )
              
            )
            
  ) %>%
    formatPercentage('感染率(%)',2) %>%
    formatPercentage('康复率(%)',2) %>%
    formatPercentage('死亡率(%)',2) %>%
    formatStyle(
      '感染率(%)',
      background = styleColorBar(x$'感染率(%)', '#31bed4'),
      backgroundSize = '100% 90%',
      backgroundRepeat = 'no-repeat',
      backgroundPosition = 'center'
    ) %>%
    formatStyle(
      '康复率(%)',
      background = styleColorBar(x$'康复率(%)', '#8bd431'),
      backgroundSize = '100% 90%',
      backgroundRepeat = 'no-repeat',
      backgroundPosition = 'center'
    ) %>%
    formatStyle(
      '死亡率(%)',
      background = styleColorBar(x$'死亡率(%)', '#ff5757'),
      backgroundSize = '100% 90%',
      backgroundRepeat = 'no-repeat',
      backgroundPosition = 'center'
    )
})





#### Forecast UI ----

output$forecastUI = renderUI({
  tagList(
    h3("基于215个国家或地区的传染病模型预测 COVID-19 病例"),
    tags$br(),
    argonRow(
      argonColumn(
        width = 3,
        pickerInput(
          inputId = "countryForecastInput",
          label = strong("选择国家或地区："),
          choices = results$dataframeTotal$countryName,
          selected = "China",
          width = "100%",
          options = list(`live-search` = TRUE),
          inline = F
        )
      ),
      argonColumn(
        width = 2,
        numericInput(
          inputId = "populationInput",
          label = strong("人口"),
          value = 1380004385,
          min = 0,
          width = "100%"
        )
      ),
      argonColumn(
        width = 2,
        numericInput(
          inputId = "fatalityInput",
          label = strong("死亡率(%)"),
          value = 0.7,
          min = 0,
          width = "100%"
        )
      ),
      argonColumn(
        width = 3,
        numericInput(
          inputId = "severeInput",
          label = strong("严重病例(%): "),
          value = 5,
          min = 0,
          width = "100%"
        )
      ),
      argonColumn(
        width = 2,
        dateInput( inputId = "dateForecast", 
                        label = strong("预测到哪一天："),
                        value = Sys.Date() + 120,
                        min = Sys.Date(),
                        format = "dd-mm-yyyy",
                        width = "100%"
        )
      )
    ),
    tags$hr(),
    uiOutput("forecastBadge") %>% withSpinner(),
    tags$br(),
    argonRow(
      argonColumn(
        width = 5,
        highchartOutput("currentScenario") %>% withSpinner()
      ),
      argonColumn(
        width = 7,
        highchartOutput("forecastedScenario") %>% withSpinner()
      )
      
    )
  )
})

observeEvent(input$countryForecastInput,{
  value = population %>%
            filter(Country == input$countryForecastInput) %>%
            .[,2] %>%
            gsub(",", "",.) %>%
            as.numeric()
  valueDeath = results$resultTable %>%
                  filter(Country == input$countryForecastInput) %>%
                  .["死亡率(%)"] %>%
                  as.numeric() * 100 %>%
                  round(.,2)
  updateNumericInput(session,
                     inputId = "populationInput",
                     value = value)
  updateNumericInput(session,
                     inputId = "fatalityInput",
                     value = valueDeath)
})

output$currentScenario = renderHighchart({
  req(!is.null(coronavirus))
  data = coronavirus %>% 
            filter(countryName == input$countryForecastInput) %>%
            filter(Confirmed > 0) %>%
            select(date,Confirmed,Recovered)
  day = 1:(nrow(data))
  lmModel <- augment(lm(log10(data$Confirmed) ~ day, data = data))
  hc <- highchart() %>% 
           hc_subtitle(text = paste0("累计感染病例在 ",input$countryForecastInput),
                       align = "left",
                       style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = data$date) %>%
    hc_yAxis(title = list(text = "感染病例 (Log-scale)"),type = "logarithmic") %>%
    hc_add_series(name = "实际情况",data = data$Confirmed,type = "scatter") %>% 
    hc_add_series(name = "拟合情况",data = 10^lmModel$.fitted,type = "line")
  
  hc %>% 
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_tooltip(crosshairs = TRUE, backgroundColor = "#FCFFC5",
               shared = TRUE, borderWidth = 5,table = T)
  
})

output$forecastedScenario = renderHighchart({
  req(!is.null(coronavirus))
  req(!is.na(input$populationInput))
  active_color <- "#1f77b4"
  recovered_color <- "forestgreen"
  death_color <- "red"
  orange_color <- "#172b4d"
  data = coronavirus %>% 
          filter(countryName == input$countryForecastInput) %>%
          filter(Confirmed > 0) %>%
          select(date,Confirmed,Recovered)
  I = data$Confirmed[1]
  R = data$Recovered[1]
  N = input$populationInput
  Day = 1:length(data$Confirmed)
  SIR <- function(time, state, parameters) {
    par <- as.list(c(state, parameters))
    with(par, {
      dS <- -beta/N * I * S
      dI <- beta/N * I * S - gamma * I
      dR <- gamma * I
      list(c(dS, dI, dR))
    })
  }
  init <- c(S = N - I, I = I, R = R)
  RSS <- function(parameters) {
    names(parameters) <- c("beta", "gamma")
    out <- ode(y = init, times = Day, func = SIR, parms = parameters)
    fit <- out[ , 3]
    sum((data$Confirmed - fit)^2)
  }
  model = optim(c(0.5, 0.5), RSS, method = "L-BFGS-B", lower = c(0, 0), upper = c(1, 1),hessian = F)
  modelPar <- setNames(model$par, c("beta", "gamma"))
  t = 1:(input$dateForecast - as.Date(min(data$date)))
  fitValue <- data.frame(ode(y = init, times = t, func = SIR, parms = modelPar))
  fitValue = fitValue %>%
                mutate(date = as.Date(min(data$date)) + time)
  results$modelFit = list(params = modelPar,fitValue = fitValue)
  hc <- highchart() %>% 
    hc_subtitle(text = paste0("预计感染病例在国家： ",input$countryForecastInput," 在时间： ",input$dateForecast),
                align = "left",
                style = list(color = "#2b908f", fontWeight = "bold")) %>%
    hc_xAxis(categories = fitValue$date) %>%
    hc_yAxis(title = list(text = "预计感染病例(Log-scale)"),type = "logarithmic") %>%
    hc_add_series(name = "敏感线",data = round(fitValue$S,0)) %>% 
    hc_add_series(name = "感染",data = round(fitValue$I,0)) %>%
    hc_add_series(name = "康复",data = round(fitValue$R,0)) %>%
    hc_add_series(name = "实际感染",data = data$Confirmed)
  
  hc %>% 
    hc_chart(borderColor = '#EBBA95',
             borderRadius = 10,
             borderWidth = 2
    ) %>%
    hc_exporting(
      enabled = TRUE
    ) %>%
    hc_colors(c(active_color,death_color,recovered_color,orange_color)) %>%
    hc_tooltip(crosshairs = T, backgroundColor = "#FCFFC5",
               shared = T, borderWidth = 5,table = T)
  
})

output$forecastBadge = renderUI({
  req(!is.null(results$modelFit))
  req(!is.null(input$fatalityInput))
  req(!is.null(input$severeInput))
  r0 = results$modelFit$params[1] / results$modelFit$params[2]
  pandemicHeight = max(results$modelFit$fitValue$I)
  deathForecast = pandemicHeight * (input$fatalityInput/100)
  severeForecast = pandemicHeight * (input$severeInput/100)
  argonRow(
    argonColumn(
      width = 3,
      argonBadge(
        text = paste0("感染率 = ",round(r0,2)),
        pill = T,
        status = ifelse(as.numeric(r0) < 1,"success",
                        ifelse(as.numeric(r0) < 1.5,"warning",
                               "danger")
                        ),
        src = "https://nivedi.res.in/Nadres_v2/ro_material.php"
      )
    ),
    argonColumn(
      width = 3,
      argonBadge(
        text = paste0("疫情高峰 = ",prettyNum(round(pandemicHeight,0),big.mark = ",")),
        pill = T,
        status = "primary"
      )
    ),
    argonColumn(
      width = 3,
      argonBadge(
        text = paste0("严重病例 = ",prettyNum(round(severeForecast,0),big.mark = ",")),
        pill = T,
        status = "warning"
      )
    ),
    argonColumn(
      width = 3,
      argonBadge(
        text = paste0("死亡直至高峰 = ",prettyNum(round(deathForecast,0),big.mark = ",")),
        pill = T,
        status = "danger"
      )
    )
  )
})



#### Sentiment analysis ----
# 用于存储预测结果
sentimentAnalResult <- reactiveValues(predictionResult = NULL)

output$predictionUI <- renderUI({
  tagList(
    argonRow(
      argonColumn(
        width = 12,
        h2("基于60万个体模型的个体感染风险预测")
      )
    ),
    argonRow(
      argonColumn(
        width = 6,
        pickerInput(
          inputId = "vaccine",
          label = "新冠疫苗接种情况:",
          choices = unique(data4$新冠疫苗接种情况),
          multiple = FALSE
        ),
        pickerInput(
          inputId = "chronic_disease",
          label = "是否患有慢性病:",
          choices = unique(data4$是否患有慢性病),
          multiple = FALSE
        ),
        pickerInput(
          inputId = "disabled",
          label = "是否伤残人士:",
          choices = unique(data4$是否伤残人士),
          multiple = FALSE
        )
      ),
      argonColumn(
        width = 6,
        pickerInput(
          inputId = "pregnant",
          label = "是否为孕妇:",
          choices = unique(data4$是否为孕妇),
          multiple = FALSE
        ),
        pickerInput(
          inputId = "role",
          label = "哪类人员:",
          choices = unique(data4$哪类人员),
          multiple = FALSE
        ),
        pickerInput(
          inputId = "gender",
          label = "性别:",
          choices = unique(data4$性别),
          multiple = FALSE
        ),
        pickerInput(
          inputId = "age_group",
          label = "年龄段:",
          choices = unique(data4$年龄段),
          multiple = FALSE
        ),
        pickerInput(
          inputId = "residence",
          label = "居住地:",
          choices = unique(data4$居住地),
          multiple = FALSE
        )
      )
    ),
    argonRow(
      argonColumn(
        width = 12,
        actionBttn(
          inputId = "runPrediction",
          label = "预测感染风险",
          color = "warning",
          block = TRUE
        )
      )
    ),
    tags$hr(),
    argonRow(
      argonColumn(
        width = 12,
        h4("预测结果:"),
        verbatimTextOutput("predictionResult")
      )
    )
  )
})

# 点击按钮触发预测
observeEvent(input$runPrediction, {
  # 验证所有输入都已选择
  req(
    input$vaccine, input$chronic_disease, input$disabled,
    input$pregnant, input$role, input$gender,
    input$age_group, input$residence
  )
  # 构建输入数据框
  new_data <- data.frame(
    新冠疫苗接种情况 = factor(input$vaccine, levels = levels(data4$新冠疫苗接种情况)),
    是否患有慢性病 = factor(input$chronic_disease, levels = levels(data4$是否患有慢性病)),
    是否伤残人士 = factor(input$disabled, levels = levels(data4$是否伤残人士)),
    是否为孕妇 = factor(input$pregnant, levels = levels(data4$是否为孕妇)),
    哪类人员 = factor(input$role, levels = levels(data4$哪类人员)),
    性别 = factor(input$gender, levels = levels(data4$性别)),
    年龄段 = factor(input$age_group, levels = levels(data4$年龄段)),
    居住地 = factor(input$residence, levels = levels(data4$居住地))
  )
  
  # 使用逻辑回归模型预测
  prediction_prob <- predict(fit3, newdata = new_data, type = "response")
  prediction <- ifelse(prediction_prob > 0.5, "感染", "未感染")
  
  # 保存结果
  sentimentAnalResult$predictionResult <- paste0(
    "预测概率: ", round(prediction_prob * 100, 2), "%\n",
    "预测结果: ", prediction
  )
})

# 输出预测结果
output$predictionResult <- renderText({
  sentimentAnalResult$predictionResult
})


#### to check which countries are new
# 
# mapdata <- get_data_from_map(download_map_data("custom/world"))
# # # 
# results$dataframeTotal$countryName[!(results$dataframeTotal$countryName %in% mapdata$name)]
# 
# [1] "Cruise Ship"
# [2] "Holy See

observeEvent(input$aggregatePlotOptions,{
  x = as.numeric(input$aggregatePlotOptions)
  divlist = c("totalCasesPlotDiv","cumulativePlotDiv","newCasesPlotDiv","newCasesDeathsPlotDiv","newCasesRecoveredPlotDiv")
  hideAllBut(divlist,x)
})
observeEvent(input$countryPlotOptions,{
  x = as.numeric(input$countryPlotOptions)
  divlist = c("cumulativeCountryPlotDiv","newCasesCountryPlotDiv",
              "newCasesDeathsCountryPlotDiv","newCasesRecoveredCountryPlotDiv")
  hideAllBut(divlist,x)
})


observeEvent(input$canvasClicked,{
  showModal(countrySpecificModal())
})






##### debug server logic #####
output$runRCodeOutput = renderPrint({
  req(rcode())
  isolate({
    eval(parse(text = rcode()$text))
  })
})
rcode = reactiveVal()
observeEvent(input$runRCodeButton, {
  rcode(list("text" = input$runRCode, "type" = "runRCode", "rand" = runif(1)))
}, ignoreNULL = TRUE, ignoreInit = TRUE)